enum MessageListViewType
{
    case normal
    case delete
}
