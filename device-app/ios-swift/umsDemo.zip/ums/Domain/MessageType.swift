enum MessageType: Int, Codable
{
    case normal = 1
    case emergency = 2
}
