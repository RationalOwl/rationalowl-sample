struct Server: Codable
{
    let regId: String
}
